print 34
print "hello world"
